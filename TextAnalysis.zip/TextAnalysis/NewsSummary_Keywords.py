#pick several sentences from original news as NewsSummary
#based on the sum of importance of words in each sentence 
#the importance of each word depend on its repeat frequancy in overall text and is the value of its own frequency divided by the maximum frequency 
#in this method, longer sentence is more likely to be picked out.
#code run in Python3 and need to install "nltk" 

#before run ".py" file in the cmd or Linux terminal, something else should be done: 
#"pip3 install nltk" in the cmd or Linux termianl
#">>>import nltk
#>>>nltk.download('stopwords')
#>>>nltk.download('punkt')
# in the python command environment


from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords #including meaningless but frequent words
from collections import defaultdict #dictionary with default value
from string import punctuation 
from heapq import nlargest

stopwords = set(stopwords.words('english') + list(punctuation))
max_cut = 0.9
min_cut = 0.1

#calculate the repeat frequency of each word
#word_sent is sentence list containg word list(splited already)
def compute_frequencies(word_sent):
    freq=defaultdict(int) #set type as "int",so default value is 0
    for s in word_sent: #"s" is list containg strings
        for word in s: #"word" is string(splited word)
            if word not in stopwords: #ignore meaningless words and punctuations 
                freq[word] += 1 #calculate the repeat frequency of each word

    m = float(max(freq.values())) #get the maximum of repeat frequency among words
    for w in list(freq.keys()):
        freq[w] = freq[w]/m #get importance of each word
        if freq[w] >= max_cut or freq[w] <= min_cut:
            del freq[w]

    return freq #dictionary: {key:word, value: importance}
			    
def summarize(text,n): # n is the number of summary sentences we want 
    sents = sent_tokenize(text) #text is the original message 
    assert n <= len(sents) #use assert to ensure error not happen 
    word_sent = [word_tokenize(s.lower()) for s in sents]
    freq = compute_frequencies(word_sent) # use the function defined before 
    
    ranking = defaultdict(int) #also build a dictionary to put the sentence and its corresponding importance like word
    for i,s in enumerate(word_sent): #enumerate function return two list: list contaning position and list containing corresponding element 
        for w in s:
            if w in freq:
                ranking[i] += freq[w]
    #according to importance of sentences to rank and get the largest n sentences
    sents_idx = rank(ranking,n) #sents_idx is a list contaning positions of the n sentences
    return [sents[j]  for j in sents_idx] # here is a cycle and the return value is a list 

def rank(ranking, n):
    return nlargest(n, ranking, key=ranking.get) #use functin in heapq to create a smallest heap for ranking, the return value is a list containing positions of the n largest 




# the main() body
# "__name__" is the property of module(module is a class object and here is the py filename "NewsSummary_keywords" 
if __name__== '__main__': # WATCH OUT!!!:here are two "_",not one
    with open("/home/shiyanlou/NewsSummary/news.txt", "r") as myfile: # open the original message
        text = myfile.read().replace('\n',' ') # replace all '\n' with ' ',so that better to split message into sentences using "sent_tokenize"
    res = summarize(text, 2)
    for i in range(len(res)):
        print(res[i])